Handling hyper-, hypo-, mero-, and holo-nyms is clumsy. Further revision would eliminate extras generated; either by comparing them with a list of thos in the articles, or with those of high frequency (relatively) words in an established dictionary.

Output of Task 1 jsons could be cleaned up considerably. I know it's simple, I just can't remember how.


future: scrolling window paragraphing